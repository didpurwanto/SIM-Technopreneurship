﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SharpGL.SceneGraph;
using SharpGL.SceneGraph.Assets;
using SharpGL;

namespace bismillah
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public double awal = 0, leher = 0, tleher = 0, tbahu = 0, bahu = 0, pangkal = 0, bawah = 0, lengan = 0, tlengan = 0, ujung = 0, tujung = 0;
        public int tipe = 0;
        public double saku1x, saku2x, saku12y, saku34y, saku11x, saku56y, saku22x, sakuy, tengahkiri, tengahkanan, tutupy, tengah;
        class Point
        {
            public double x, y;
            public void setxy(double x2, double y2) { x = x2; y = y2; }
        };

        public MainWindow()
        {
            InitializeComponent();
            awal = 0.75;
            leher = 0.15;
            tleher = 0.2;
            tbahu = 0.06;
            bahu = 0.22;
            pangkal = 0.4;
            bawah = 1.4;
        }

        void LenganPanjang()
        {
            lengan = 0.45;
            tlengan = 0.9;
            ujung = (awal - tbahu - pangkal) / 2.5;
            tujung = ujung;
        }

        void LenganPendek()
        {
            lengan = 0.45 / 1.5;
            tlengan = 0.9 / 3;
            ujung = (awal - tbahu - pangkal) / 1.5;
            tujung = ujung;
        }

        void UkurSaku() 
        {
            // Ukuran Saku
            saku1x = leher + leher / 6;
            saku2x = saku1x + bahu / 1.8;
            saku11x = saku1x + (saku2x - saku1x) / 5.0;
            saku22x = saku2x - (saku2x - saku1x) / 5.0;
            saku12y = awal - tbahu - pangkal;
            saku34y = awal - bawah / 2.0;
            saku56y = saku34y + saku34y / 2.0;
        }

        void DrawLine(double a, double b, double c, double d)
        {
            OpenGL gl = openGLControl.OpenGL;
            gl.Color(1.0, 1.0, 1.0);
            gl.Begin(OpenGL.GL_LINE_LOOP);
            //gl.Color(1.0, 1.0, 1.0);
            gl.LineWidth(1.0f);
            gl.Vertex(a, b);
            gl.Vertex(c, d);
            gl.End();
        }

        Point drawSpline_1(Point A, Point B, Point C, Point D, double t)
        {
            var P = new Point();
            P.x = (-Math.Pow(t, 3) + 3 * Math.Pow(t, 2) - 3 * t + 1) * A.x + (3 * Math.Pow(t, 3) - 6 * Math.Pow(t, 2) + 3 * t) * B.x + (-3 * Math.Pow(t, 3) + 3 * Math.Pow(t, 2)) * C.x + Math.Pow(t, 3) * D.x;
            P.y = (-Math.Pow(t, 3) + 3 * Math.Pow(t, 2) - 3 * t + 1) * A.y + (3 * Math.Pow(t, 3) - 6 * Math.Pow(t, 2) + 3 * t) * B.y + (-3 * Math.Pow(t, 3) + 3 * Math.Pow(t, 2)) * C.y + Math.Pow(t, 3) * D.y;
            return P;
        }

        List<Point> DrawCurve(Point a, Point b, Point c, Point d)
        {
            OpenGL gl = openGLControl.OpenGL;
            List<Point> box = new List<Point>();

            Point POld1 = a;
            box.Add(POld1);
            // Draw each segment of the curve. Make t increment in smaller amounts for a more detailed curve
            for (double t = 0.0; t <= 1.04; t += 0.05)
            {
                Point P1 = drawSpline_1(a, b, c, d, t);
                //DrawLine(POld1.x, POld1.y, P1.x, P1.y);
                POld1 = P1;
                box.Add(POld1);
            }
            return box;
        }

        void DrawCurve2(Point a, Point b, Point c, Point d)
        {
            OpenGL gl = openGLControl.OpenGL;

            Point POld1 = a;
            // Draw each segment of the curve. Make t increment in smaller amounts for a more detailed curve
            for (double t = 0.0; t <= 1.04; t += 0.05)
            {
                Point P1 = drawSpline_1(a, b, c, d, t);
                DrawLine(POld1.x, POld1.y, P1.x, P1.y);
                POld1 = P1;
            }
        }

        

        void gambarDasar()
        {
            double nilai = 0.35;
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kancing = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;
            
            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\batik6.jpg");

            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            gl.TexCoord(leher, awal); gl.Vertex(leher, awal);
            gl.TexCoord(-leher, awal); gl.Vertex(-leher, awal);
            gl.TexCoord(-leher - bahu, awal - tbahu); gl.Vertex(-leher - bahu, awal - tbahu);
            gl.TexCoord(-leher - bahu, awal - bawah); gl.Vertex(-leher - bahu, awal - bawah);
            gl.TexCoord(leher + bahu, awal - bawah); gl.Vertex(leher + bahu, awal - bawah);
            gl.TexCoord(leher + bahu, awal - tbahu); gl.Vertex(leher + bahu, awal - tbahu);
            gl.End();


            if (tipe == 1)
            {
                List<Point> box = new List<Point>();
                a.setxy(leher, awal);
                b.setxy(leher, awal - 0.2);
                c.setxy(-leher, awal - 0.2);
                d.setxy(-leher, awal);
                box = DrawCurve(a, b, c, d);

                gl.Enable(OpenGL.GL_TEXTURE_2D);
                texture.Create(openGLControl.OpenGL, "D:\\belakang.jpg");
                gl.Begin(OpenGL.GL_POLYGON);
                gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
                box.ForEach(delegate(Point po)
                {

                    gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                });
                gl.End();
            }
            else if (tipe == 2)
            {
                DrawLine(0.0, awal - 0.2, 0.0, awal - bawah);
                gl.Enable(OpenGL.GL_TEXTURE_2D);
                texture.Create(openGLControl.OpenGL, "D:\\belakang.jpg");
                gl.Begin(OpenGL.GL_POLYGON);
                gl.TexCoord(-leher, awal); gl.Vertex(-leher, awal);
                gl.TexCoord(leher, awal); gl.Vertex(leher, awal);
                gl.TexCoord(0, awal - 0.2); gl.Vertex(0, awal - 0.2);
                gl.End();

                gl.Enable(OpenGL.GL_TEXTURE_2D);
                texture.Create(openGLControl.OpenGL, "D:\\kuning.png");
                for (int i = 0; i <= 6; i++)
                {
                    a.setxy(-0.03, awal - nilai);
                    b.setxy(-0.03, awal - nilai - 0.02);
                    c.setxy(-0.01, awal - nilai - 0.02);
                    d.setxy(-0.01, awal - nilai);
                    kancing = DrawCurve(a, b, c, d);
                    gl.Begin(OpenGL.GL_POLYGON);
                    kancing.ForEach(delegate(Point po)
                    {
                        gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                    });
                    gl.End();
                    a.setxy(-0.01, awal - nilai);
                    b.setxy(-0.01, awal - nilai + 0.02);
                    c.setxy(-0.03, awal - nilai + 0.02);
                    d.setxy(-0.03, awal - nilai);
                    kancing = DrawCurve(a, b, c, d);
                    gl.Begin(OpenGL.GL_POLYGON);
                    kancing.ForEach(delegate(Point po)
                    {
                        gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                    });
                    gl.End();

                    nilai += 0.15;
                }
            }
            else if (tipe == 3)
            {
                DrawLine(0.0, awal - 0.2, 0.0, awal - 0.5);
                gl.Enable(OpenGL.GL_TEXTURE_2D);
                texture.Create(openGLControl.OpenGL, "D:\\kuning.png");
                for (int i = 0; i <= 1; i++)
                {
                    a.setxy(-0.03, awal - nilai);
                    b.setxy(-0.03, awal - nilai - 0.02);
                    c.setxy(-0.01, awal - nilai - 0.02);
                    d.setxy(-0.01, awal - nilai);
                    kancing = DrawCurve(a, b, c, d);
                    gl.Begin(OpenGL.GL_POLYGON);
                    kancing.ForEach(delegate(Point po)
                    {
                        gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                    });
                    gl.End();
                    a.setxy(-0.01, awal - nilai);
                    b.setxy(-0.01, awal - nilai + 0.02);
                    c.setxy(-0.03, awal - nilai + 0.02);
                    d.setxy(-0.03, awal - nilai);
                    kancing = DrawCurve(a, b, c, d);
                    gl.Begin(OpenGL.GL_POLYGON);
                    kancing.ForEach(delegate(Point po)
                    {
                        gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                    });
                    gl.End();

                    nilai += 0.1;
                }
            }
        }

        void gambarLengan()
        {
            OpenGL gl = openGLControl.OpenGL;
            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\batik6.jpg");

            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            gl.TexCoord(leher + bahu, awal - tbahu - pangkal); gl.Vertex(leher + bahu, awal - tbahu - pangkal);
            gl.TexCoord(leher + bahu + lengan - ujung, awal - tbahu - tlengan - tujung); gl.Vertex(leher + bahu + lengan - ujung, awal - tbahu - tlengan - tujung);
            gl.TexCoord(leher + bahu + lengan, awal - tbahu - tlengan); gl.Vertex(leher + bahu + lengan, awal - tbahu - tlengan);
            gl.TexCoord(leher + bahu, awal - tbahu); gl.Vertex(leher + bahu, awal - tbahu);
            gl.End();

            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            gl.TexCoord(-leher - bahu, awal - tbahu); gl.Vertex(-leher - bahu, awal - tbahu);
            gl.TexCoord(-leher - bahu - lengan, awal - tbahu - tlengan); gl.Vertex(-leher - bahu - lengan, awal - tbahu - tlengan);
            gl.TexCoord(-leher - bahu - lengan + ujung, awal - tbahu - tlengan - tujung); gl.Vertex(-leher - bahu - lengan + ujung, awal - tbahu - tlengan - tujung);
            gl.TexCoord(-leher - bahu, awal - tbahu - pangkal); gl.Vertex(-leher - bahu, awal - tbahu - pangkal);
            gl.End();
        }

        void gambarLenganPendek()
        {
            LenganPendek();
            gambarLengan();
            if (tipe == 2)
            {
                DrawLine(-leher - bahu - lengan + 0.046, awal - tbahu - tlengan + 0.049, -leher - bahu - lengan + ujung + 0.046, awal - tbahu - tlengan - tujung + 0.049);
                DrawLine(leher + bahu + lengan - 0.046, awal - tbahu - tlengan + 0.049, leher + bahu + lengan - ujung - 0.046, awal - tbahu - tlengan - tujung + 0.049);
            }
        }

        void gambarLenganPendekKancing()
        {
            double nilai = 0.35;
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kancing = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;
 
            LenganPendek();
            gambarLengan();
            if (tipe == 2)
            {
                DrawLine(-leher - bahu - lengan + 0.046, awal - tbahu - tlengan + 0.049, -leher - bahu - lengan + ujung + 0.046, awal - tbahu - tlengan - tujung + 0.049);
                DrawLine(leher + bahu + lengan - 0.046, awal - tbahu - tlengan + 0.049, leher + bahu + lengan - ujung - 0.046, awal - tbahu - tlengan - tujung + 0.049);

                a.setxy(-leher - bahu - lengan + 0.05, awal - tbahu - tlengan - 0.05);
                b.setxy(-leher - bahu - lengan - 0.1, awal - tbahu - tlengan);
                c.setxy(-leher - bahu - lengan, awal - tbahu - tlengan + 0.05);
                d.setxy(-leher - bahu - lengan + 0.1, awal - tbahu - tlengan + 0.1);
                DrawCurve2(a, b, c, d);
                

                a.setxy(leher + bahu + lengan - 0.1, awal - tbahu - tlengan + 0.1);
                b.setxy(leher + bahu + lengan, awal - tbahu - tlengan + 0.05);
                c.setxy(leher + bahu + lengan + 0.1, awal - tbahu - tlengan);
                d.setxy(leher + bahu + lengan - 0.05, awal - tbahu - tlengan - 0.05);
                DrawCurve2(a, b, c, d);
                gl.Begin(OpenGL.GL_POLYGON);
                kancing.ForEach(delegate(Point po)
                {
                    gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                });
                gl.End();

                gl.Enable(OpenGL.GL_TEXTURE_2D);
                texture.Create(openGLControl.OpenGL, "D:\\kuning.png");
                // kancing kiri
                a.setxy(-leher - bahu - lengan + 0.1 - 0.01, awal - tbahu - tlengan + 0.1);
                b.setxy(-leher - bahu - lengan + 0.1 - 0.01, awal - tbahu - tlengan + 0.1 + 0.02);
                c.setxy(-leher - bahu - lengan + 0.1 + 0.01, awal - tbahu - tlengan + 0.1 + 0.02);
                d.setxy(-leher - bahu - lengan + 0.1 + 0.01, awal - tbahu - tlengan + 0.1);
                kancing = DrawCurve(a, b, c, d);
                gl.Begin(OpenGL.GL_POLYGON);
                kancing.ForEach(delegate(Point po)
                {
                    gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                });
                gl.End();

                a.setxy(-leher - bahu - lengan + 0.1 - 0.01, awal - tbahu - tlengan + 0.1);
                b.setxy(-leher - bahu - lengan + 0.1 - 0.01, awal - tbahu - tlengan + 0.1 - 0.02);
                c.setxy(-leher - bahu - lengan + 0.1 + 0.01, awal - tbahu - tlengan + 0.1 - 0.02);
                d.setxy(-leher - bahu - lengan + 0.1 + 0.01, awal - tbahu - tlengan + 0.1);
                kancing = DrawCurve(a, b, c, d);
                gl.Begin(OpenGL.GL_POLYGON);
                kancing.ForEach(delegate(Point po)
                {
                    gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                });
                gl.End();

                // kancing kanan
                a.setxy(leher + bahu + lengan - 0.1 - 0.01, awal - tbahu - tlengan + 0.1);
                b.setxy(leher + bahu + lengan - 0.1 - 0.01, awal - tbahu - tlengan + 0.1 + 0.02);
                c.setxy(leher + bahu + lengan - 0.1 + 0.01, awal - tbahu - tlengan + 0.1 + 0.02);
                d.setxy(leher + bahu + lengan - 0.1 + 0.01, awal - tbahu - tlengan + 0.1);
                kancing = DrawCurve(a, b, c, d);
                gl.Begin(OpenGL.GL_POLYGON);
                kancing.ForEach(delegate(Point po)
                {
                    gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                });
                gl.End();

                a.setxy(leher + bahu + lengan - 0.1 - 0.01, awal - tbahu - tlengan + 0.1);
                b.setxy(leher + bahu + lengan - 0.1 - 0.01, awal - tbahu - tlengan + 0.1 - 0.02);
                c.setxy(leher + bahu + lengan - 0.1 + 0.01, awal - tbahu - tlengan + 0.1 - 0.02);
                d.setxy(leher + bahu + lengan - 0.1 + 0.01, awal - tbahu - tlengan + 0.1);
                kancing = DrawCurve(a, b, c, d);
                gl.Begin(OpenGL.GL_POLYGON);
                kancing.ForEach(delegate(Point po)
                {
                    gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
                });
                gl.End();
            }
        }

        void gambarLenganPanjang()
        {
            LenganPanjang();
            gambarLengan();
            if (tipe == 2)
            {
                DrawLine(leher + bahu + lengan - 0.033, awal - tbahu - tlengan + 0.062, leher + bahu + lengan - ujung - 0.033, awal - tbahu - tlengan - tujung + 0.062);
                DrawLine(-leher - bahu - lengan + 0.033, awal - tbahu - tlengan + 0.062, -leher - bahu - lengan + ujung + 0.033, awal - tbahu - tlengan - tujung + 0.062);
            }
        }

        void gambarKerahStraightPoin()
        {
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kerah = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            DrawLine(-leher, awal, leher, awal);
            a.setxy(-0.05, awal - 0.3);
            b.setxy(-leher - 0.01, awal - 0.1);
            c.setxy(-leher - 0.01, awal);
            d.setxy(-leher, awal);
            kerah = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.TexCoord(-0.05, awal - 0.3); gl.Vertex(-0.05, awal - 0.3);
            gl.TexCoord(0, awal - 0.2); gl.Vertex(0, awal - 0.2);
            gl.TexCoord(-leher, awal); gl.Vertex(-leher, awal);
            gl.End();

            a.setxy(leher, awal);
            b.setxy(leher + 0.01, awal);
            c.setxy(leher + 0.01, awal - 0.1);
            d.setxy(0.05, awal - 0.3);
            kerah = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.TexCoord(0.05, awal - 0.3); gl.Vertex(0.05, awal - 0.3);
            gl.TexCoord(0, awal - 0.2); gl.Vertex(0, awal - 0.2);
            gl.TexCoord(leher, awal); gl.Vertex(leher, awal);
            gl.End();
            
        }

        void gambarKerahButtonDown()
        {
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kerah = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            DrawLine(-leher, awal, leher, awal);
            a.setxy(-0.05, awal - 0.3);
            b.setxy(-leher - 0.01, awal - 0.1);
            c.setxy(-leher - 0.01, awal);
            d.setxy(-leher, awal);
            kerah = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            
            a.setxy(0.0, awal - 0.2);
            b.setxy(-0.025, awal - 0.1);
            c.setxy(-0.025, awal - 0.4);
            d.setxy(-0.05, awal - 0.3);
            kerah = DrawCurve(a, b, c, d);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.TexCoord(-leher, awal); gl.Vertex(-leher, awal);
            gl.End();


            a.setxy(leher, awal);
            b.setxy(leher + 0.01, awal);
            c.setxy(leher + 0.01, awal - 0.1);
            d.setxy(0.05, awal - 0.3);
            kerah = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            
            a.setxy(0.0, awal - 0.2);
            b.setxy(0.025, awal - 0.1);
            c.setxy(0.025, awal - 0.4);
            d.setxy(0.05, awal - 0.3);
            kerah = DrawCurve(a, b, c, d);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();




        }

        void gambarKerahSpread()
        {
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kerah = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            DrawLine(-leher, awal, leher, awal);
            a.setxy(-leher, awal - 0.23);
            b.setxy(-leher - 0.01, awal);
            c.setxy(-leher, awal);
            d.setxy(-leher, awal);
            kerah = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });

            a.setxy(0.0, awal - 0.2);
            b.setxy(-0.01, awal - 0.22);
            c.setxy(-0.02, awal - 0.22);
            d.setxy(-leher, awal - 0.23);
            kerah = DrawCurve(a, b, c, d);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });

            gl.End();


            a.setxy(leher, awal);
            b.setxy(leher, awal);
            c.setxy(leher + 0.01, awal);
            d.setxy(leher, awal - 0.23);
            kerah = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            kerah.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });

            a.setxy(0.0, awal - 0.2);
            b.setxy(0.01, awal - 0.22);
            c.setxy(0.02, awal - 0.22);
            d.setxy(leher, awal - 0.23);
            kerah = DrawCurve(a, b, c, d);
            kerah.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();
        }

        void gambarKerahSemiSpread()
        {
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kerah = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            DrawLine(-leher, awal, leher, awal);
            a.setxy(-0.1, awal - 0.25);
            b.setxy(-leher - 0.01, awal - 0.1);
            c.setxy(-leher - 0.01, awal);
            d.setxy(-leher, awal);
            kerah = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.TexCoord(-0.1, awal - 0.25); gl.Vertex(-0.1, awal - 0.25);
            gl.TexCoord(0, awal - 0.2); gl.Vertex(0, awal - 0.2);
            gl.TexCoord(-leher, awal); gl.Vertex(-leher, awal);
            gl.End();

            a.setxy(leher, awal);
            b.setxy(leher + 0.01, awal);
            c.setxy(leher + 0.01, awal - 0.1);
            d.setxy(0.1, awal - 0.25);
            kerah = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            gl.Color(1.0f, 1.0f, 1.0f, 1.0f);
            kerah.ForEach(delegate(Point po)
            {

                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.TexCoord(0.1, awal - 0.25); gl.Vertex(0.1, awal - 0.25);
            gl.TexCoord(0, awal - 0.2); gl.Vertex(0, awal - 0.2);
            gl.TexCoord(leher, awal); gl.Vertex(leher, awal);
            gl.End();
        }

        void gambarSakuTegas()
        {
            UkurSaku();
            OpenGL gl = openGLControl.OpenGL;

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            gl.Begin(OpenGL.GL_POLYGON);
            gl.TexCoord(saku1x, saku12y); gl.Vertex(saku1x, saku12y);
            gl.TexCoord(saku2x, saku12y); gl.Vertex(saku2x, saku12y);
            gl.TexCoord(saku2x, saku56y); gl.Vertex(saku2x, saku56y);
            gl.TexCoord(saku22x, saku34y); gl.Vertex(saku22x, saku34y);
            gl.TexCoord(saku11x, saku34y); gl.Vertex(saku11x, saku34y);
            gl.TexCoord(saku1x, saku56y); gl.Vertex(saku1x, saku56y);
            gl.End();
            
        }

        void gambarSakuClassic()
        {
            OpenGL gl = openGLControl.OpenGL;
            gambarSakuTegas();
            sakuy = saku12y + (saku56y - saku12y) / 5;
            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            DrawLine(saku1x, sakuy, saku2x, sakuy);
        }

        void gambarSakuBoxPleat()
        {
            OpenGL gl = openGLControl.OpenGL;
            gambarSakuTegas();
            tengahkiri = saku1x + (saku2x - saku1x) / 3;
            tengahkanan = saku2x - (saku2x - saku1x) / 3;
            sakuy = saku12y + (saku56y - saku12y) / 5;
            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            DrawLine(saku1x, sakuy, saku2x, sakuy);
            DrawLine(tengahkiri, saku12y, tengahkiri, saku34y);
            DrawLine(tengahkanan, saku12y, tengahkanan, saku34y);
        }

        void gambarSakuClassicFlap()
        {
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kancing = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;
            gambarSakuTegas();
            tengah = (saku1x + saku2x) / 2;
            tengahkiri = saku1x + (saku2x - saku1x) / 3;
            tengahkanan = saku2x - (saku2x - saku1x) / 3;
            sakuy = saku12y + (saku56y - saku12y) / 5;
            tutupy = sakuy - saku34y / 2.0;
            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            DrawLine(saku1x, sakuy, saku11x, tutupy);
            DrawLine(saku11x, tutupy, saku22x, tutupy);
            DrawLine(saku22x, tutupy, saku2x, sakuy);

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kuning.png");
            sakuy = sakuy - 0.01;
            a.setxy(tengah - 0.003, sakuy);
            b.setxy(tengah - 0.003, sakuy + 0.01);
            c.setxy(tengah + 0.003, sakuy + 0.01);
            d.setxy(tengah + 0.003, sakuy);
            kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();

            a.setxy(tengah + 0.003, sakuy);
            b.setxy(tengah + 0.003, sakuy - 0.01);
            c.setxy(tengah - 0.003, sakuy - 0.01);
            d.setxy(tengah - 0.003, sakuy);
            kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();
        }

        void gambarSakuBoxPleatFlap()
        {
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kancing = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;
            gambarSakuTegas();

            tengahkiri = saku1x + (saku2x - saku1x) / 3;
            tengahkanan = saku2x - (saku2x - saku1x) / 3;
            sakuy = saku12y + (saku56y - saku12y) / 5;
            tutupy = sakuy - saku34y / 2.0;

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");

            DrawLine(saku1x, sakuy, saku11x, tutupy);
            DrawLine(saku11x, tutupy, saku22x, tutupy);
            DrawLine(saku22x, tutupy, saku2x, sakuy);
            DrawLine(tengahkiri, tutupy, tengahkiri, saku34y);
            DrawLine(tengahkanan, tutupy, tengahkanan, saku34y);


            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kuning.png");
            tengah = (saku1x + saku2x) / 2;
            sakuy = sakuy - 0.01;
            a.setxy(tengah - 0.003, sakuy);
            b.setxy(tengah - 0.003, sakuy + 0.01);
            c.setxy(tengah + 0.003, sakuy + 0.01);
            d.setxy(tengah + 0.003, sakuy);
            kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();

            a.setxy(tengah + 0.003, sakuy);
            b.setxy(tengah + 0.003, sakuy - 0.01);
            c.setxy(tengah - 0.003, sakuy - 0.01);
            d.setxy(tengah - 0.003, sakuy);
            kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();
        }

        void gambarSakuInvertedPleat()
        {
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kancing = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;
            gambarSakuTegas();

            tengah = (saku1x + saku2x) / 2;
            sakuy = saku12y + (saku56y - saku12y) / 5;

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            DrawLine(saku1x, sakuy, saku2x, sakuy);


            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kuning.png");
            a.setxy(tengah, saku34y);
            b.setxy(tengah - 0.005, saku34y + 0.05);
            c.setxy(tengah - 0.005, sakuy - 0.05);
            d.setxy(tengah, sakuy);
            DrawCurve(a, b, c, d); kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();
            a.setxy(tengah, sakuy);
            b.setxy(tengah + 0.005, sakuy - 0.05);
            c.setxy(tengah + 0.005, saku34y + 0.05);
            d.setxy(tengah, saku34y);
            kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();
        }

        void gambarLengkungLancip()
        {
            UkurSaku();
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kancing = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            saku1x = saku1x + 0.01;
            saku2x = saku2x - 0.01;
            tengah = (saku1x + saku2x) / 2;
            a.setxy(tengah, saku34y + 0.02);
            b.setxy(saku1x, (saku34y + saku12y) / 2 - 0.03);
            c.setxy(saku1x, saku56y);
            d.setxy(saku1x, saku12y);
            kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            a.setxy(saku2x, saku12y);
            b.setxy(saku2x, saku56y);
            c.setxy(saku2x, (saku34y + saku12y) / 2 - 0.03);
            d.setxy(tengah, saku34y + 0.02);
            kancing = DrawCurve(a, b, c, d);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();
            DrawLine(saku1x, saku12y, saku2x, saku12y);
        }

        void gambarSakuRegulerDress()
        {
            OpenGL gl = openGLControl.OpenGL;

            gambarLengkungLancip();
            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            sakuy = saku12y + (saku56y - saku12y) / 5;
            DrawLine(saku1x, sakuy, tengah, sakuy - 0.04);
            DrawLine(saku2x, sakuy, tengah, sakuy - 0.04);
        }

        void gambarSakuRegulerDressFlap()
        {
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kancing = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;

            gambarLengkungLancip();
            sakuy = saku12y + (saku56y - saku12y) / 5;
            
            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kuning.png");
            DrawLine(saku1x, sakuy, tengah, sakuy - 0.04);
            DrawLine(saku2x, sakuy, tengah, sakuy - 0.04);
            sakuy = sakuy - 0.02;
            a.setxy(tengah - 0.003, sakuy);
            b.setxy(tengah - 0.003, sakuy + 0.01);
            c.setxy(tengah + 0.003, sakuy + 0.01);
            d.setxy(tengah + 0.003, sakuy);
            kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();

            a.setxy(tengah + 0.003, sakuy);
            b.setxy(tengah + 0.003, sakuy - 0.01);
            c.setxy(tengah - 0.003, sakuy - 0.01);
            d.setxy(tengah - 0.003, sakuy);
            kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();
        }

        void gambarSakuRegulerSport()
        {
            Point a = new Point();
            Point b = new Point();
            Point c = new Point();
            Point d = new Point();
            List<Point> kancing = new List<Point>();
            OpenGL gl = openGLControl.OpenGL;
            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kotak5.jpg");
            UkurSaku();
            tengah = (saku1x + saku2x) / 2.0;
            a.setxy(tengah, saku34y);
            b.setxy(saku1x, saku34y);
            c.setxy(saku1x, saku56y);
            d.setxy(saku1x, saku12y);
            kancing = DrawCurve(a, b, c, d);
            gl.Begin(OpenGL.GL_POLYGON);
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            
            a.setxy(saku2x, saku12y);
            b.setxy(saku2x, saku56y);
            c.setxy(saku2x, saku34y);
            d.setxy(tengah, saku34y);
            kancing = DrawCurve(a, b, c, d);
            
            kancing.ForEach(delegate(Point po)
            {
                gl.TexCoord(po.x, po.y); gl.Vertex(po.x, po.y);
            });
            gl.End();

            gl.Enable(OpenGL.GL_TEXTURE_2D);
            texture.Create(openGLControl.OpenGL, "D:\\kuning.png");
            DrawLine(saku1x, saku12y, saku2x, saku12y);
            sakuy = saku12y + (saku56y - saku12y) / 5;
            DrawLine(saku1x, sakuy, tengah, sakuy - 0.03);
            DrawLine(saku2x, sakuy, tengah, sakuy - 0.03);
        }

        Texture texture = new Texture();
        private void openGLControl_OpenGLDraw(object sender, OpenGLEventArgs args)
        {
            //  Get the OpenGL object.
            OpenGL gl = openGLControl.OpenGL;

            //  Clear the color and depth buffer.
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

            //  Load the identity matrix.
            gl.LoadIdentity();
            // tipe ==> 1=kaos, 2=kemeja, 3=kaos kerah
            tipe = 2;
            
            gambarDasar();

            gambarLenganPendek();
            //gambarLenganPendekKancing();
            //gambarLenganPanjang();

            //gambarKerahStraightPoin();
            gambarKerahButtonDown();
            //gambarKerahSpread();
            //gambarKerahSemiSpread();


            //gambarSakuClassic();
            //gambarSakuBoxPleat();
            //gambarSakuClassicFlap();
            //gambarSakuBoxPleatFlap();
            //gambarSakuInvertedPleat();
            //gambarSakuRegulerDress();
            //gambarSakuRegulerDressFlap();
            gambarSakuRegulerSport();

            gl.Flush();
        }


        private void openGLControl_OpenGLInitialized(object sender, OpenGLEventArgs args)
        {
            OpenGL gl = openGLControl.OpenGL;
            gl.ClearColor(1, 1, 1, 1);
        }


        private void openGLControl_Resized(object sender, OpenGLEventArgs args)
        {
            //  TODO: Set the projection matrix here.

        }
    }
}
